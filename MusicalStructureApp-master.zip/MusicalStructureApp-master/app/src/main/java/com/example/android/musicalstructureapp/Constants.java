package com.example.android.musicalstructureapp;

interface Constants {

    //Used to keep activity state
    String SONG_PATH = "songPath";
    String SONG_NAME = "songName";
    String SONG_ALBUM_IMAGE = "songAlbumImage";
}
